package com.example.sel;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SelApplication {

	public static void main(String[] args) {
		SpringApplication.run(SelApplication.class, args);
	}

}
