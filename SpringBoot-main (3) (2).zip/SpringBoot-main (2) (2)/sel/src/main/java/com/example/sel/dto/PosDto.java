package com.example.sel.dto;

public class PosDto {

    private String posCode;

    private String posName;

    private String deptCode;

    public String getPosCode() {
        return posCode;
    }

    public String getPosName() {
        return posName;
    }

    public String getDeptCode() {
        return deptCode;
    }

    public void setPosCode(String posCode) {
        this.posCode = posCode;
    }

    public void setPosName(String posName) {
        this.posName = posName;
    }

    public void setDeptCode(String deptCode) {
        this.deptCode = deptCode;
    }
}
