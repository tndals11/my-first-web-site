package com.example.krpizzaPrj.mappers;

import com.example.krpizzaPrj.dto.AskDto;
import com.example.krpizzaPrj.dto.OptionsDto;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface AskMapper {

    @Insert("INSERT INTO ask VALUES(NULL,#{optionCode}, #{subject},#{content}, 0, NOW(), #{orgName}, #{savedFileName}, #{savedFilePathName}, #{savedFileSize}, #{folderName}, #{ext}, #{grp}, 1, 1)")
    void setAsk(AskDto askDto);

    @Select("SELECT * FROM options ORDER BY option_code ASC")
    List<OptionsDto> getOptionAll();
}
