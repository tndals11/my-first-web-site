package com.example.krpizzaPrj;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KrpizzaPrjApplicationTests {

	@Test
	void contextLoads() {
	}

}
