package com.example.krpizzaPrj;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KrpizzaPrjApplication {

	public static void main(String[] args) {
		SpringApplication.run(KrpizzaPrjApplication.class, args);
	}

}
